export const resultsContainer = document.querySelector(".results__container");
export const favouritesContainer = document.querySelector(".favourites__container");
export const cleanBtnContainer = document.querySelector(".clean--btn__container");
export const loaderContainer = document.querySelector(".loading");
