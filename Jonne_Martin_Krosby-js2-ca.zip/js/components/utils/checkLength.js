export function checkLength(value, len) {
  if (value.trim().length > len) {
      return value;
  } 
}